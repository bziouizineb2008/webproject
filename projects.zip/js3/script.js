let img = document.getElementById('myImage');
let images = ['1.png', '2.png', '3.png'];
let i = 0;

 function sideshow() {
    img.setAttribute('src', images[i]);

    if (i == images.length -1 ) {
        i = 0;
    }
    else{
        i++;
    }
    setTimeout(sideshow, 2000);
}
sideshow();