var elmtInput = document.getElementById("inputMsg");
var elmtBtn = document.getElementById("addMsg");
var elmtMsgList = document.getElementById("messageList");

elmtBtn.onclick = function () {

    var msg = elmtInput.value;
    if (msg != ''){
        elmtMsgList.innerHTML += '<p>' + msg + '</p>';
        elmtInput.value = '';
    }
}