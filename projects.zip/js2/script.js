var btn=document.getElementById("myButton");
var input=document.getElementById("myInput");

btn.onclick = function(){
    if (btn.getAttribute("data-text")=='show'){
        input.setAttribute("type","text");
        btn.setAttribute("data-text","hide");
        btn.innerText="Hide";
    }
    else{
        input.setAttribute("type","password");
        btn.setAttribute("data-text","show");
        btn.innerText="Show";
    }
}