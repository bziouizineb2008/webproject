const display = document.getElementById('display');

// متغير لتخزين حالة الشاشة (هل نحتاج لمسحها عند كتابة رقم جديد؟)
let resetDisplay = false;

// 2. وظيفة إضافة الأرقام والرموز للشاشة
function addToDisplay(value) {
    // إذا كانت الشاشة تحتوي على "0" أو نحتاج لإعادة ضبطها، نمسحها أولاً
    if (display.innerText === '0' || resetDisplay) {
        display.innerText = value;
        resetDisplay = false;
    } else {
        display.innerText += value;
    }
}

// 3. وظيفة مسح الشاشة (AC)
function clearDisplay() {
    display.innerText = '0';
}

// 4. وظيفة حساب النتيجة النهائية (=)
function calculate() {
    try {
        // استبدال الرموز التجميلية برموز برمجية قبل الحساب
        let expression = display.innerText.replace('×', '*').replace('÷', '/');
        
        // استخدام eval لحساب النص الرياضي
        let result = eval(expression);
        
        // التأكد من أن النتيجة لا تحتوي على فواصل عشرية لا نهائية
        display.innerText = Number.isInteger(result) ? result : result.toFixed(2);
        resetDisplay = true; // لكي يبدأ برقم جديد بعد النتيجة
    } catch (error) {
        display.innerText = 'خطأ';
        resetDisplay = true;
    }
}

// 5. وظيفة النسبة المئوية (%)
function percentage() {
    let currentValue = parseFloat(display.innerText);
    display.innerText = currentValue / 100;
}

// 6. وظيفة عكس الإشارة (+/-)
function toggleSign() {
    let currentValue = parseFloat(display.innerText);
    display.innerText = currentValue * -1;
}