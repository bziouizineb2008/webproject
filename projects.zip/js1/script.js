var btn = document.querySelector('.color');
var changeColorBtn = document.querySelector('.changeColor');
var colors = ['red', 'blue', 'green', 'yellow', 'orange', 'purple' , 'pink' , 'brown', 'black', 'white' , 'gray', 'cyan', 'magenta', 'lime', 'maroon', 'navy', 'olive', 'teal', 'violet', 'indigo'];
 var i = 0;
changeColorBtn.onclick = function() {
    btn.style.backgroundColor = colors[i];
    i++;
    if (i >= colors.length) {
        i = 0;
    }
}